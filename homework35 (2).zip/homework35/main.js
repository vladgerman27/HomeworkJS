window.addEventListener("load" , () => {
	let input = document.forms ['calc'].elements['expression'];

	let div =  document.getElementById("result");

	input.addEventListener("input", () => {
		const value = input.value;

        var a = value.match(/[-+*^()en\/]|"sin()"|"cos()"|"sqrt()"|"ln()"|\d+/g);
        var result=0; 

        if (a===null)
        { 
            return 0;
        }

        for (var i=0; i < a.length; i++) 
        {

        if (i===0)  {
                    result = parseInt(a[i]);
                    } 
                        
                        switch (a[i])
                        {
                        case '+' :
                        result += parseInt(a[i+1]);
                        ++i;
                        break;
                           
                        case '-':
                        result -= parseInt(a[i+1]);
                        ++i;
                        break;
                        
                        case '/':
                        result /= parseInt(a[i+1]);  
                        ++i;
                        break;
                        
                        case '*':
                        result *= parseInt(a[i+1]);  
                        ++i;
                        break;    

                        case '^':
                        result **= parseInt(a[i+1]);  
                        ++i;
                        break;  

                        case 'sin()':
                        result = Math.sin(parseInt(a[i+1]));  
                        ++i;
                        break;    

                        case 'cos()':
                        result = Math.cos(parseInt(a[i+1]));  
                        ++i;
                        break;    

                        case 'sqrt()':
                        result = Math.sqrt(parseInt(a[i+1]));  
                        ++i;
                        break;  

                        case 'ln()':
                        result = Math.ln(parseInt(a[i+1]));  
                        ++i;
                        break;

                        case 'e':
                        result = Math.pow(parseInt(a[i+1]));  
                        ++i;
                        break;  

                        case 'n':
                        result = Math.PI; 
                        }

        } 
		div.innerHTML = result;
	})
})
	